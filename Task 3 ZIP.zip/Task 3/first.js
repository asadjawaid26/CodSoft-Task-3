let input = '';
let operator = '';
let result = 0;

function clearDisplay() {
    input = '';
    operator = '';
    result = 0;
    updateDisplay();
}

function appendInput(value) {
    input += value;
    updateDisplay();
}

function setOperator(op) {
    operator = op;
    if (input !== '') {
        result = parseFloat(input);
        input = '';
    }
    updateDisplay();
}

function calculateResult() {
    if (input !== '') {
        const secondOperand = parseFloat(input);
        switch (operator) {
            case '+':
                result += secondOperand;
                break;
            case '-':
                result -= secondOperand;
                break;
            case '*':
                result *= secondOperand;
                break;
            case '/':
                result /= secondOperand;
                break;
        }
        input = '';
        operator = '';
        updateDisplay();
    }
}

function updateDisplay() {
    document.getElementById('display').innerText = input !== '' ? input : result;
}